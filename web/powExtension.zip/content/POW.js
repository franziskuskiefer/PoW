/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this file,
 * You can obtain one at http://mozilla.org/MPL/2.0/. */

var pow = {
	
useLibCrypto: true,
	
session: {},
	
onLoad: function() {
	gBrowser.addEventListener("DOMContentLoaded", this.onPageLoad, false);
	pow.sessions = new Array();
	if (pow.useLibCrypto) {
		console.log("loading native libraries");
		pow.libcryptoInit();
	}
},
	
onUnload: function() {
	gBrowser.removeEventListener("load", this.onPageLoad, true);
	if (pow.useLibCrypto) pow.libcryptoFree();
},
	
	
onPageLoad: function(aEvent) {
	pow.doc = aEvent.originalTarget;
	pow.startExperience(false);
},
	
startExperience: function(isTryingAgain) {
	
	pow.win = pow.doc.defaultView;
	pow.domain = pow.doc.domain;
	
	// only run POW if this is the top window and not a frame
	if (pow.win != pow.win.top) return;
	if (pow.win.frameElement) return;
	
	// is SSL being used?
	if (pow.win.location.protocol != "https:") return;
	var certHash;
	var ui = gBrowser.selectedBrowser.securityUI;
	if (ui instanceof Components.interfaces.nsISecureBrowserUI) {
		var status = ui.QueryInterface(Ci.nsISSLStatusProvider).SSLStatus;
		if (status instanceof Ci.nsISSLStatus) {
			var currentCert = status.serverCert;
			certHash = currentCert.sha1Fingerprint.replace(new RegExp(":","gm"),"");
		}
	} else return;
	
	// is there a POW element in the webpage?
	var powIDPresent = pow.doc.getElementById("POW-fe748ad9-37f9-4b56-80a8-5c73b73e3e88");
	var win = window.top.getBrowser().selectedBrowser.contentWindow;
	var jsonPOWServerHello = win.wrappedJSObject.params;
	var jsonPOWServerHello;
	if (powIDPresent) {} else return;

	// inject invisible div to say hello I'm installed
//	var idiv = document.createElement("div");
//	var a = document.createAttribute("style");
//	a.value = "display: none;";
//	idiv.setAttributeNode(a);
//	pow.doc.insertBefore(idiv, powIDPresent);

	// version negotiation
	if (jsonPOWServerHello.versions.length < 1) {
		Application.console.log("POW versions not valid: " + jsonPOWServerHello.versions);
		return;
	}
	var foundVersion = 0;
	for (var i = 0; i < jsonPOWServerHello.versions.length; i++) {
		if (jsonPOWServerHello.versions[i] === "POW_v1_tSOKE_secp192r1_SHA256_certHash") {
			foundVersion = 1;
			break;
		}
	}
	if (!foundVersion) {
		Application.console.log("Unsupported POW version: " + jsonPOWServerHello.version);
		return;
	}
	
	// delete old session if it exists
	var sessionID = jsonPOWServerHello.sessionID;
	for (var i = pow.sessions.length - 1; i >= 0; i--) {
		if (pow.sessions[i].sessionID == sessionID) {
			pow.sessions.splice(i, 1);
		}
	}

	// set up new POW session
	var currentSession = new POWSession("POW_v1_tSOKE_secp192r1_SHA256_certHash", sessionID, certHash, jsonPOWServerHello.authURL);
	pow.sessions.push(currentSession);
	currentSession.msgPOWServerHello = JSON.stringify(jsonPOWServerHello);
	
	// save variables
	if (jsonPOWServerHello.sitename) {
		currentSession.sitename = jsonPOWServerHello.sitename;
	} else {
		currentSession.sitename = pow.domain;
	}
	if (jsonPOWServerHello.description) {
		currentSession.description = jsonPOWServerHello.description;
	}
	if (jsonPOWServerHello.imgURL) {
		currentSession.imgURL = jsonPOWServerHello.imgURL;
	}
	if (jsonPOWServerHello.usernameLabel) {
		currentSession.usernameLabel = jsonPOWServerHello.usernameLabel;
	}
	switch (jsonPOWServerHello.passwordLabel) {
		case "Password":
		case "PIN":
		case "Passphrase":
		case "Pass phrase":
		case "Secret phrase":
			currentSession.passwordLabel = jsonPOWServerHello.passwordLabel;
			break;
		default:
			break;
	}
	if (jsonPOWServerHello.forgotLabel) {
		currentSession.forgotLabel = jsonPOWServerHello.forgotLabel;
	}
	if (jsonPOWServerHello.forgotURL) {
		currentSession.forgotURL = jsonPOWServerHello.forgotURL;
	}
	if (jsonPOWServerHello.failURL) {
		currentSession.failURL = jsonPOWServerHello.failURL;
	}
	
	// setup login dialog box
	var loginButton = new Object();
	loginButton.label = "Login";
	loginButton.accessKey = "L";
	loginButton.popup = null;
	loginButton.callback = function() {
		window.openDialog("chrome://pow/content/logindialog.xul","showmore", "chrome", currentSession, pow).focus();
	};
	
	if (!isTryingAgain) {
		// display notification bar
		pow.clearNotification();
		var nb = gBrowser.getNotificationBox();
		nb.appendNotification("This site supports secure password authentication.  Click 'Login' to proceed." , "pow-notification" , "chrome://pow/skin/icon.png" , nb.PRIORITY_INFO_HIGH , [loginButton]);
	} else {
		window.openDialog("chrome://pow/content/logindialog.xul","showmore", "chrome", currentSession, pow).focus();
	}
	
},
	
// construct and send the initial POW request
powInit: function(currentSession) {
	
	// TIMING
//	currentSession.totalClientTime = 0;
//	var startTime = window.performance.now();
//	currentSession.totalTimeStart = startTime;

	// X <- xG
	if (pow.useLibCrypto) {
		var ret = pow.lc_POW_client_gen().readString();
		var ret_arr = ret.split("|");
		currentSession.clientPriv = ret_arr[0];
		currentSession.clientPub = ret_arr[1];
	} else {
		// x <- {2, ..., n-1}
		var n = getSECCurveByName("secp192r1").getN();
		var G = getSECCurveByName("secp192r1").getG();
		var rng = new SecureRandom();
		var n1 = n.subtract(BigInteger.ONE);
		var r = new BigInteger(n.bitLength(), rng);
		currentSession.clientPriv = r.mod(n1).add(BigInteger.ONE);
		// X <- xG
		currentSession.clientPub = G.multiply(currentSession.clientPriv);
		currentSession.clientPub = getSECCurveByName("secp192r1").getCurve().encodePointHex(currentSession.clientPub);
	}

	// construct protocol message (sessionID, version, username, X)
	var params = "msg=POWClientExchange";
	params += "&version=" + encodeURIComponent(currentSession.version);
	params += "&sessionID=" + encodeURIComponent(currentSession.sessionID);
	params += "&username=" + encodeURIComponent(currentSession.sessionUsername);
	params += "&clientPoint=" + currentSession.clientPub.toLowerCase();
	currentSession.msgPOWClientExchange = params;
	
	// TIMING
//	var stopTime = window.performance.now();
//	currentSession.totalClientTime += (stopTime - startTime);

	// send (id, username, X) to server
	currentSession.state = "initiated";
	pow.doHttpRequest(currentSession.authURL, params);
	
},

stateManager: function(responseText) {
	
	var responseObj;
	try {
		responseObj = JSON.parse(responseText);
	} catch(err) {
		pow.showAlert("Password authentication error: An unknown error occurred while communicating with the server.", 1);
		Components.utils.reportError("POW response: " + responseText);
		return;
	}
	
	var currentSession;
	for (var i = 0; i < pow.sessions.length; i++) {
		if (pow.sessions[i].sessionID == responseObj.sessionID) {
			currentSession = pow.sessions[i];
			break;
		}
	}
	
	switch(responseObj.msg) {

		case "POWServerExchange":
		case "POWServerFinished":
			break;

		case "ERROR_USERNAME_NOT_FOUND":
			pow.showAlert("Secure password authentication failed: the username you entered was not found.", !(currentSession && currentSession.failURL));
			if (currentSession && currentSession.failURL) {
				window.setTimeout(function() {
								  pow.win.location.href = currentSession.failURL;
								  }, 1000);
			}
			return;
			
		case "ERROR_INVALID_PASSWORD":
			pow.showAlert("Secure password authentication failed: the password you entered does not match the server's.", !(currentSession && currentSession.failURL));
			if (currentSession && currentSession.failURL) {
				window.setTimeout(function() {
								  pow.win.location.href = currentSession.failURL;
								  }, 1000);
			}
			return;
			
		case "ERROR":
		case "ERROR_UNSUPPORTED_VERSION":
		case "ERROR_SESSION_NOT_FOUND":
		default:
			pow.showAlert("Password authentication error: An unknown error occurred while communicating with the server.", 1);
			if (responseObj.error) {
				Components.utils.reportError("POW response error: " + responseObj.error);
			}
			return;
			
	}
	
	if (!currentSession) {
		pow.showAlert("Password authentication error: A protocol error occurred while communicating with the server.", 1);
		Components.utils.reportError("POW error (-20)");
		return;
		
	}
	
	switch(responseObj.msg) {
			
		case "POWServerExchange": // server->client message 1 (salt, Y^*)
			
			if (currentSession.state != "initiated") {
				pow.showAlert("Password authentication error: A protocol error occurred while communicating with the server.", 1);
				Application.console.log("POW error (-21)");
				return;
			}
			currentSession.msgPOWServerExchange = responseText;
			// if we received all parameters, calculate session key
			if (responseObj.sessionID && responseObj.salt && responseObj.serverPoint) {
				pow.calculateSessionKey(currentSession, responseObj);
			} else {
				pow.showAlert("Password authentication error: A protocol error occurred while communicating with the server.", 1);
				Components.utils.reportError("POW error (-22)");
				return;
			}
			break;
			
		case "POWServerFinished": // server->client message 2 (auth2)
			if (currentSession.state != "clientkey") {
				pow.showAlert("Password authentication error: A protocol error occurred while communicating with the server.", 1);
				Components.utils.reportError("POW error (-23)");
				return;
			}
			currentSession.msgPOWServerConfirm = responseText;
			if (responseObj.sessionID && responseObj.auth2) {
				// check if the authentication string is correct
				// if so, redirect to the success URL, otherwise redirect to authentication URL
				if (responseObj.auth2 == currentSession.a2) {

					// TIMING
//					var stopTime = window.performance.now();
//					window.alert("Client time: " + currentSession.totalClientTime + "ms\nTotal time: " + (stopTime - currentSession.totalTimeStart) + "ms");
					
					var nb = gBrowser.getNotificationBox();
					nb.appendNotification("Secure password authentication succeeded.  Connecting...", "pow-notification", "chrome://pow/skin/icon_green.png", nb.PRIORITY_INFO_LOW);
					window.setTimeout(function() {
						pow.win.location.href = responseObj.successURL;
					}, 1000);
				} else {
					// TIMING
//					var stopTime = window.performance.now();
//					window.alert("Client time: " + currentSession.totalClientTime + "ms\nTotal time: " + (stopTime - currentSession.totalTimeStart) + "ms");
					pow.showAlert("Secure password authentication failed: the server's password does not match the one you entered.", 1);
					return;
				}
			} else {
				pow.showAlert("Password authentication error: A protocol error occurred while communicating with the server.", 1);
				Components.utils.reportError("POW error (-24)");
				return;
			}
			break;
			
		default:
			// assert: this will never be reached
			break;
			
	}
	
},

calculateSessionKey: function(currentSession, responseObj) {
	
	// TIMING
//	var startTime = window.performance.now();
	
	var passHash;
	var Z;
	
	if (pow.useLibCrypto) {
		var ret = pow.lc_POW_client_resp(responseObj.salt, currentSession.sessionPassword, responseObj.serverPoint, currentSession.clientPriv).readString();
		var ret_arr = ret.split("|");
		passHash = ret_arr[0];
		Z = ret_arr[1];
	} else {
		salt = sjcl.codec.utf8String.toBits(responseObj.salt);
		var curve = getSECCurveByName("secp192r1");
		var n = curve.getN();
		var G1 = curve.getCurve().decodePointHex("048da36f68628a18107650b306f22b41448cb60fe5712dd57a1f64a649852124528a09455de6aad151b4c0a9a8c2e8269c");		
		// h <- PBKDF2(SHA-256, pw, salt)
		passHash = sjcl.misc.pbkdf2(currentSession.sessionPassword, salt);
		passHash = sjcl.codec.hex.fromBits(passHash);
		// Y <- Y^* - (h mod n) G1
		var h1 = new BigInteger(passHash, 16);
		h1 = h1.mod(n);
		var hG1 = G1.multiply(h1);
		hG1 = hG1.negate();
		var Y1 = curve.getCurve().decodePointHex(responseObj.serverPoint);
		var Y = Y1.add(hG1);
		// Z <- xY
		var Z = Y.multiply(currentSession.clientPriv);
		Z = curve.getCurve().encodePointHex(Z);
	}
	
	// k <- SHA-256(POWServerHello, POWClientExchange, POWServerExchange, passHash, certHash, sharedSecret)
	var k = "POWServerHello=" + encodeURIComponent(currentSession.msgPOWServerHello);
	k += "&POWClientExchange=" + encodeURIComponent(currentSession.msgPOWClientExchange);
	k += "&POWServerExchange=" + encodeURIComponent(currentSession.msgPOWServerExchange);
	k += "&passHash=" + passHash.toLowerCase();
	k += "&certHash=" + currentSession.certHash.toLowerCase();
	k += "&sharedSecret=" + Z.toLowerCase();
	k = sjcl.hash.sha256.hash(k);
	k = sjcl.codec.hex.fromBits(k);
	
	// A1 <- SHA-256(k, "auth1")
	var a1 = sjcl.hash.sha256.hash(k + "&auth1");
	a1 = sjcl.codec.hex.fromBits(a1);
	
	// A2 <- SHA-256(k, "auth2")
	currentSession.a2 = sjcl.hash.sha256.hash(k + "&auth2");
	currentSession.a2 = sjcl.codec.hex.fromBits(currentSession.a2);
	
	// construct outgoing message
	var sessionID = encodeURIComponent(currentSession.sessionID);
	a1 = encodeURIComponent(window.btoa(a1));
	var params = "msg=POWClientFinished&sessionID=" + sessionID + "&auth1=" + a1;
	currentSession.msgPOWClientConfirm = params;
	
	// TIMING
//	var stopTime = window.performance.now();
//	currentSession.totalClientTime += (stopTime - startTime);
	
	// send to server
	currentSession.state = "clientkey";
	pow.doHttpRequest(currentSession.authURL, params);
	
},

doHttpRequest: function(url, params) {

	var httpRequest = Components.classes["@mozilla.org/xmlextras/xmlhttprequest;1"].createInstance();
	httpRequest.mozBackgroundRequest = true;
	
	httpRequest.open("POST", url, true);
	httpRequest.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	httpRequest.setRequestHeader("Content-length", params.length);
	httpRequest.setRequestHeader("Connection", "close");
	httpRequest.send(params);
	httpRequest.onreadystatechange = function (aEvt) {
		if (httpRequest.readyState == 4) {
			pow.stateManager(httpRequest.responseText);
		}
	};
	
},

clearNotification: function() {
	var nb = gBrowser.getNotificationBox();
	var oldnotification = nb.getNotificationWithValue("pow-notification");
	if (oldnotification) {
		nb.removeNotification(oldnotification);
	}
},
	
showAlert: function(msg, tryAgain) {

	var nb = gBrowser.getNotificationBox();
	pow.clearNotification();

	if (tryAgain) {
		// try again
		var tryAgainButton = new Object();
		tryAgainButton.label = "Try again";
		tryAgainButton.accessKey = "T";
		tryAgainButton.popup = null;
		tryAgainButton.callback = function() {
			pow.startExperience(true);
		};
		nb.appendNotification(msg, "pow-notification", "chrome://pow/skin/icon_red.png", nb.PRIORITY_WARNING_MEDIUM, [tryAgainButton]);
	} else {
		nb.appendNotification(msg, "pow-notification", "chrome://pow/skin/icon_red.png", nb.PRIORITY_WARNING_MEDIUM);
	}
	
},
	
libcryptoInit: function() {
	Components.utils.import("resource://gre/modules/ctypes.jsm");
	pow.libcrypto = ctypes.open("libcrypto.so");
	pow.libcrypto = ctypes.open("libssl.so");
	pow.libcrypto = ctypes.open("/home/franziskus/.mozilla/firefox/ij7p8e3l.ConfirmationDemo/extensions/pow@webcryptography.org/lib/libpow.so");
	pow.lc_POW_client_gen = pow.libcrypto.declare("POW_client_gen", ctypes.default_abi, ctypes.char.ptr);
	pow.lc_POW_client_resp = pow.libcrypto.declare("POW_client_resp", ctypes.default_abi, ctypes.char.ptr, ctypes.char.ptr, ctypes.char.ptr, ctypes.char.ptr, ctypes.char.ptr);
},

libcryptoFree: function() {
	pow.libcrypto.close();
}

};
