function POWSession(version, sessionID, cert, authURL) {
	this.version = version;
	this.sessionID = sessionID;
	this.certHash = cert;
	this.authURL = authURL;
	this.msgPOWServerHello;
	this.msgPOWClientExchange;
	this.msgPOWServerExchange;
	this.msgPOWClientFinished;
	this.msgPOWServerFinished;
	this.sitename;
	this.description;
	this.imgURL;
	this.usernameLabel;
	this.passwordLabel;
	this.forgotLabel;
	this.forgotURL;
	this.failURL;
	this.state;
	this.clientPriv;
	this.sessionKey;
	this.sessionUsername;
	this.sessionPassword;
	this.clientPub;
	this.a2;
	// TIMING
	// this.totalClientTime;
	// this.totalTimeStart;
}
