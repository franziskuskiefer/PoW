PAKE
=========
Password Authenticated Key Exchange is an alternative web authentication mechanism which allows for extra security for users.
This extension enables PAKE authentication in Firefox on supported websites.


Usage
-----
When you visit websites which support PAKE you will be notified by a notification box prompt. You can then
proceed to login using PAKE if desired, if not normal HTTP authentication is still available.


Source Code
-----------
The source code for PAKE is made available under the [Mozilla Public
License 2.0](https://www.mozilla.org/MPL/2.0/index.txt)
Github address is: 


