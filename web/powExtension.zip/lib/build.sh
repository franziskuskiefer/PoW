#!/bin/bash
gcc pow.c -c -o pow.o -lssl -lcrypto -fPIC -ldl -O3  -Wall
gcc -shared pow.o -lcrypto -lssl -o libpow.so
