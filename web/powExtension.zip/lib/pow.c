#include <openssl/aes.h>
#include <openssl/asn1.h>
#include <openssl/asn1_mac.h>
#include <openssl/asn1t.h>
#include <openssl/bio.h>
#include <openssl/blowfish.h>
#include <openssl/bn.h>
#include <openssl/buffer.h>
#include <openssl/camellia.h>
#include <openssl/cast.h>
#include <openssl/cmac.h>
#include <openssl/cms.h>
#include <openssl/comp.h>
#include <openssl/conf_api.h>
#include <openssl/conf.h>
#include <openssl/crypto.h>
#include <openssl/des.h>
#include <openssl/des_old.h>
#include <openssl/dh.h>
#include <openssl/dsa.h>
#include <openssl/dso.h>
#include <openssl/ebcdic.h>
#include <openssl/ecdh.h>
#include <openssl/ecdsa.h>
#include <openssl/ec.h>
#include <openssl/engine.h>
#include <openssl/e_os2.h>
#include <openssl/err.h>
#include <openssl/evp.h>
#include <openssl/hmac.h>
#include <openssl/idea.h>
#include <openssl/krb5_asn.h>
#include <openssl/kssl.h>
#include <openssl/lhash.h>
#include <openssl/md4.h>
#include <openssl/md5.h>
#include <openssl/mdc2.h>
#include <openssl/modes.h>
#include <openssl/objects.h>
#include <openssl/obj_mac.h>
#include <openssl/ocsp.h>
#include <openssl/opensslconf.h>
#include <openssl/opensslv.h>
#include <openssl/ossl_typ.h>
#include <openssl/pem2.h>
#include <openssl/pem.h>
#include <openssl/pkcs12.h>
#include <openssl/pkcs7.h>
#include <openssl/pqueue.h>
#include <openssl/rand.h>
#include <openssl/rc2.h>
#include <openssl/rc4.h>
#include <openssl/ripemd.h>
#include <openssl/rsa.h>
#include <openssl/safestack.h>
#include <openssl/seed.h>
#include <openssl/sha.h>
#include <openssl/srp.h>
#include <openssl/srtp.h>
#include <openssl/ssl23.h>
#include <openssl/ssl2.h>
#include <openssl/ssl3.h>
#include <openssl/ssl.h>
#include <openssl/stack.h>
#include <openssl/symhacks.h>
#include <openssl/tls1.h>
#include <openssl/ts.h>
#include <openssl/txt_db.h>
#include <openssl/ui_compat.h>
#include <openssl/ui.h>
#include <openssl/whrlpool.h>
#include <openssl/x509.h>
#include <openssl/x509v3.h>
#include <openssl/x509_vfy.h>

char *POW_client_gen() {
	EC_GROUP *secp192r1;
	EC_POINT *kP;
	BIGNUM *k, *n;
	char *k_str, *kP_str;
	char *ret;
	int ret_len;
	
	k = BN_new(); BN_init(k);
	n = BN_new(); BN_init(n);
	secp192r1 = EC_GROUP_new_by_curve_name(NID_X9_62_prime192v1);
	EC_GROUP_get_order(secp192r1, n, NULL);
	BN_rand_range(k, n);
	k_str = BN_bn2dec(k);
	kP = EC_POINT_new(secp192r1);
	EC_POINT_mul(secp192r1, kP, k, NULL, NULL, NULL);
	kP_str = EC_POINT_point2hex(secp192r1, kP, POINT_CONVERSION_UNCOMPRESSED, NULL);
	BN_free(k);
	EC_POINT_free(kP);
	EC_GROUP_free(secp192r1);
	ret_len = strlen(k_str) + 1 + strlen(kP_str) + 1;
	ret = OPENSSL_malloc(sizeof(char) * ret_len);
	memset(ret, 0, ret_len);
	strcat(ret, k_str);
	strcat(ret, "|");
	strcat(ret, kP_str);
	return ret;
}

char *POW_client_resp(char *salt_str, char *pw_str, char *server_point_str, char *k_str) {
	EC_GROUP *secp192r1;
	EC_POINT *server_point, *gen_one, *shared;
	BIGNUM *k, *h, *n;
	BN_CTX *ctx;
	char *hash_str, *shared_str, *ret;
	unsigned char *hash;
	int ret_len;
	
	hash = OPENSSL_malloc(sizeof(unsigned char) * SHA256_DIGEST_LENGTH);
	PKCS5_PBKDF2_HMAC(pw_str, strlen(pw_str), (unsigned char *) salt_str, strlen(salt_str), 1000, EVP_sha256(), SHA256_DIGEST_LENGTH, hash);
	
	ctx = BN_CTX_new();
	k = BN_new(); BN_init(k);
	h = BN_new(); BN_init(h);
	n = BN_new(); BN_init(n);
	BN_dec2bn(&k, k_str);
	BN_bin2bn(hash, SHA256_DIGEST_LENGTH, h);
	hash_str = BN_bn2hex(h);
	secp192r1 = EC_GROUP_new_by_curve_name(NID_X9_62_prime192v1);
	EC_GROUP_get_order(secp192r1, n, ctx);
	BN_mod(h, h, n, ctx);
	gen_one = EC_POINT_hex2point(secp192r1, "048da36f68628a18107650b306f22b41448cb60fe5712dd57a1f64a649852124528a09455de6aad151b4c0a9a8c2e8269c", NULL, ctx);
	EC_POINT_mul(secp192r1, gen_one, NULL, gen_one, h, ctx);
	EC_POINT_invert(secp192r1, gen_one, ctx);
	server_point = EC_POINT_hex2point(secp192r1, server_point_str, NULL, ctx);
	EC_POINT_add(secp192r1, server_point, server_point, gen_one, ctx);
	shared = EC_POINT_new(secp192r1);
	EC_POINT_mul(secp192r1, shared, NULL, server_point, k, ctx);
	shared_str = EC_POINT_point2hex(secp192r1, shared, POINT_CONVERSION_UNCOMPRESSED, ctx);
	BN_free(k);
	BN_free(h);
	BN_free(n);
	EC_POINT_free(gen_one);
	EC_POINT_free(server_point);
	EC_POINT_free(shared);
	EC_GROUP_free(secp192r1);
	BN_CTX_free(ctx);
	OPENSSL_free(hash);
	ret_len = strlen(hash_str) + 1 + strlen(shared_str) + 1;
	ret = OPENSSL_malloc(sizeof(char) * ret_len);
	memset(ret, 0, ret_len);
	strcat(ret, hash_str);
	strcat(ret, "|");
	strcat(ret, shared_str);
	OPENSSL_free(hash_str);
	OPENSSL_free(shared_str);
	return ret;
}

char *POW_server(char *h_str, char *client_point_str) {
	EC_GROUP *secp192r1;
	EC_POINT *kP, *client_point, *gen_one, *shared;
	BIGNUM *k, *h, *n;
	BN_CTX *ctx;
	char *kP_str, *shared_str, *ret;
	int ret_len;
	
	ctx = BN_CTX_new();
	k = BN_new(); BN_init(k);
	n = BN_new(); BN_init(n);
	secp192r1 = EC_GROUP_new_by_curve_name(NID_X9_62_prime192v1);
	EC_GROUP_get_order(secp192r1, n, ctx);
	BN_rand_range(k, n);
	kP = EC_POINT_new(secp192r1);
	EC_POINT_mul(secp192r1, kP, k, NULL, NULL, ctx);
	
	h = BN_new(); BN_init(h);
	BN_hex2bn(&h, h_str);
	BN_mod(h, h, n, ctx);
	gen_one = EC_POINT_hex2point(secp192r1, "048da36f68628a18107650b306f22b41448cb60fe5712dd57a1f64a649852124528a09455de6aad151b4c0a9a8c2e8269c", NULL, ctx);
	EC_POINT_mul(secp192r1, gen_one, NULL, gen_one, h, ctx);
	EC_POINT_add(secp192r1, kP, kP, gen_one, ctx);
	kP_str = EC_POINT_point2hex(secp192r1, kP, POINT_CONVERSION_UNCOMPRESSED, ctx);
	
	shared = EC_POINT_new(secp192r1);
	client_point = EC_POINT_hex2point(secp192r1, client_point_str, NULL, ctx);
	EC_POINT_mul(secp192r1, shared, NULL, client_point, k, ctx);
	shared_str = EC_POINT_point2hex(secp192r1, shared, POINT_CONVERSION_UNCOMPRESSED, ctx);
	
	BN_free(k);
	BN_free(h);
	BN_free(n);
	EC_POINT_free(gen_one);
	EC_POINT_free(client_point);
	EC_POINT_free(shared);
	EC_POINT_free(kP);
	EC_GROUP_free(secp192r1);
	BN_CTX_free(ctx);
	ret_len = strlen(kP_str) + 1 + strlen(shared_str) + 1;
	ret = OPENSSL_malloc(sizeof(char) * ret_len);
	memset(ret, 0, ret_len);
	strcat(ret, kP_str);
	strcat(ret, "|");
	strcat(ret, shared_str);
	OPENSSL_free(kP_str);
	OPENSSL_free(shared_str);
	return ret;
}
