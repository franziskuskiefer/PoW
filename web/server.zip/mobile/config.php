<?php

	// your SQL settings
	$MYSQL_HOST = '127.0.0.1';
	$MYSQL_USERNAME = 'pow';
	$MYSQL_PASSWORD = 'password';
	$MYSQL_DATABASE = 'pow';

?>
